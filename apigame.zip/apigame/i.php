<?php
include 'config.php';
$time=time();
if($_SESSION['lasttime']==$time){
		$return=array(
			'errcode'=>1,
			'info'=>'brushing too fast',
		);
		exit(json_encode($return));	
}
$_SESSION['lasttime']=$time;
if($_POST){
	$checknum=trim('gmhen');
	if($checknum!=$gmcode){
		$return=array(
			'errcode'=>1,
			'info'=>'GM code error',
		);
		exit(json_encode($return));
	}
	$quid=trim('1');
	if($quid==''){
		$return=array(
			'errcode'=>1,
			'info'=>'wrong area code',
		);
		exit(json_encode($return));
	}
	$config=$quarr[$quid];
	if(!$config){
		$return=array(
			'errcode'=>1,
			'info'=>'Zone configuration does not exist',
		);
		exit(json_encode($return));
	}
	$uid=trim('pororo');
	if($uid==''){
		$return=array(
			'errcode'=>1,
			'info'=>'game account error',
		);
		exit(json_encode($return));
	}
	
	$roleid=$uid;
	if('charge'){
		$type=trim('charge');
		switch ($type){
			case 'charge':
				$id=trim('2');
				$charge=$charges[(string)$id];
				if(!$charge){
					$return=array(
						'errcode'=>1,
						'info'=>'No recharge configuration found',
					);
					exit(json_encode($return));	
				}
				mysql_connect("127.0.0.1","root","123456");
				//Insert a piece of data first
				//recharge
				$sql="select * from `jymf`.`user` where `username`='".$uid."' limit 1";
				$result=mysql_query($sql);
				$row=mysql_fetch_array($result);
				$total=mysql_num_rows($result);
				if($row['userId']=='' || $total<1){
					$return=array(
						'errcode'=>1,
						'info'=>'The character ID corresponding to the game account cannot be queried',
					);
					exit(json_encode($return));
				}
				$uid=$row['userId'];
				$sql="select * from jymf.billnotable where uid='".$uid."' order by billid desc limit 1";
				$result=mysql_query($sql);
				$row=mysql_fetch_array($result);
				$total=mysql_num_rows($result);
				if($total>0){			
					$data = array(
					//"appid" =>0,
						"gameid"=>0,
						"channelid"=>0,
						"serverid"=>$quid, 
						"playerid"=>$row['playerid'],
						"uid"=>$uid, 
						"billno"=>md5(time().rand(1000,9999)), 
						"goodsid"=>$charge['id'],
						"money"=>$charge['money'],
						"payext"=>1
					);
					$rtn=post($chargeurl,$data);
					$return=array(
						'errcode'=>0,
						'info'=>$rtn.$row['playerid'],
					);
					exit(json_encode($return));
					break;
				}else{
					$return=array(
						'errcode'=>1,
						'info'=>'Failed to retrieve character information, please let the player click any amount to recharge in the game',
					);
					exit(json_encode($return));
					break;
				}
			case 'mail':
				include('MySocket.class.php');
				$socket = new MySocket('127.0.0.1',21400);
				$socket->connect();
				$iErr   = $socket->getSocketError();
				if($iErr == 0) {
					$uid=dechex($uid);
					$uid=(strlen($uid) % 2 ==0) ? $uid : '0'.$uid;
					$uid1=str_pad($uid,18,'0',STR_PAD_LEFT);
					$uid2=str_pad($uid,16,'0',STR_PAD_LEFT);
					$itemid=$_POST['itemid'];
					$itemnum=$_POST['itemnum'];
					$itemid=dechex($itemid);
					$itemid=(strlen($itemid) % 2 ==0) ? $itemid : '0'.$itemid;
					$itemid=str_pad($itemid,8,'0',STR_PAD_LEFT);
					$itemnum=dechex($itemnum);
					$itemnum=(strlen($itemnum) % 2 ==0) ? $itemnum : '0'.$itemnum;
					$itemnum=str_pad($itemnum,8,'0',STR_PAD_LEFT);
					$sendStr = '908B56800001'.strtoupper($uid1).'000000C000003FF300000001'.strtoupper($uid2).'00005A7A68CD010000000000000400003FC9';
					$sendStr.= '0000000000000000000000000000000001'.strtoupper($itemid).strtoupper($itemnum).'0000000000000000000000';
					$result = $socket->sendMsgAndReturnResult($sendStr);
					$result = json_decode(base64_decode($result));
					$socket->close();
					if($result->error==0){
						$return=array(
							'errcode'=>0,
							'info'=>'Sent successfully'.json_encode($result)
						);
					}else{
						$return=array(
							'errcode'=>1,
							'info'=>'Failed to send'
						);
					}
				}else{
					$return=array(
						'errcode'=>1,
						'info'=>'Server connection failed'
					);
				}
				exit(json_encode($return));
				break;
				
			case 'addczvip':
				$pswd=trim($_POST['pswd']);
				if($pswd==''){
					$return=array(
						'errcode'=>1,
						'info'=>'Authorization password cannot be empty',
					);
					exit(json_encode($return));
				}
				$vipfile='jymf_'.$quid.'.json';
				$fp = fopen($vipfile,"a+");
				if(filesize($vipfile)>0){
					$str = fread($fp,filesize($vipfile));
					fclose($fp);
					$vipjson=json_decode($str,true);
					if($vipjson==null){
						$vipjson=array();
					}
				}else{
					$vipjson=array();
				}
				if(!$vipjson[$roleid]){
					$vipjson[$roleid]=array('pswd'=>$pswd,'level'=>0);
					file_put_contents($vipfile,json_encode($vipjson));
					$return=array(
						'errcode'=>0,
						'info'=>'Join VIP successfully'
					);
					exit(json_encode($return));
				}else{
					$return=array(
						'errcode'=>0,
						'info'=>'This ID is already VIP'
					);
					exit(json_encode($return));
				}
				break;
			case 'addvip':
				$pswd=trim($_POST['pswd']);
				if($pswd==''){
					$return=array(
						'errcode'=>1,
						'info'=>'Background password cannot be empty',
					);
					exit(json_encode($return));
				}
				$vipfile='jymf_'.$quid.'.json';
				$fp = fopen($vipfile,"a+");
				if(filesize($vipfile)>0){
					$str = fread($fp,filesize($vipfile));
					fclose($fp);
					$vipjson=json_decode($str,true);
					if($vipjson==null){
						$vipjson=array();
					}
				}else{
					$vipjson=array();
				}
				if(!$vipjson[$roleid] || intval($vipjson[$roleid]['level']==0)){
					$vipjson[$roleid]=array('pswd'=>$pswd,'level'=>1);
					file_put_contents($vipfile,json_encode($vipjson));
					$return=array(
						'errcode'=>0,
						'info'=>'Join or upgrade VIP successfully'
					);
					exit(json_encode($return));
				}else{
					$return=array(//Pro-test source code network www.qc ym w.com
						'errcode'=>0,
						'info'=>'This ID is already VIP.'
					);
					exit(json_encode($return));
				}
				break;
			default:
				$return=array(
					'errcode'=>1,
					'info'=>'type error',
				);
				exit(json_encode($return));
				break;
		}
	}else{
	$return=array(
		'errcode'=>1,
		'info'=>'no type',
	);
	exit(json_encode($return));
	}
}else{
	$return=array(
		'errcode'=>1,
		'info'=>'must post',
	);
	exit(json_encode($return));
}