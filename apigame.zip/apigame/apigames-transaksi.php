<?php
  	$curl = curl_init();
  
    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://v1.apigames.id/transaksi/http-get-v1?merchant=M220724MEJL5966WU&secret=b0a670ff506d8829a6d4bcd86d4a7c295a4cec03a4d4cc8ae48f1f2af8a14ad6&produk=AGFF5&tujuan=5011314646&ref=TRX0002',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
  ));
  $response = curl_exec($curl);
 
  curl_close($curl);

//   $data = json_decode($response,true);

// $status=$data['data']['status'];
echo $response;


    ?>