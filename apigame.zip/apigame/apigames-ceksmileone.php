<?php
  	$curl = curl_init();
  
    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://v1.apigames.id/merchant/M220724MEJL5966WU/cek-koneksi?engine=smileone&signature=7d68135ab7e07a5ec021c39fb2a0c184',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
  ));
  $response = curl_exec($curl);
 
  curl_close($curl);

//   $data = json_decode($response,true);

// $status=$data['data']['status'];
echo $response;


    ?>